<?php
// Determine current page (default = dashboard)
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$validPages = ['dashboard', 'event_results', 'game_schedule'];
if (!in_array($page, $validPages)) {
    $page = 'dashboard';
}

// Handle POST requests for event_results and game_schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($page === 'event_results') {
        include "pages/event_results_backend.php";
        exit();
    } elseif ($page === 'game_schedule') {
        include "pages/game_schedule_backend.php";
        exit();
    }
}

// Simple navigation (React's switch-case equivalent)
function renderPage($page)
{
    switch ($page) {
        case 'dashboard':
            include "pages/dashboard.php";
            break;
        case 'event_results':
            include "pages/event_results.php";
            break;
        case 'game_schedule':
            include "pages/game_schedule.php";
            break;
    }
}

include "includes/header.php";
renderPage($page);
include "includes/footer.php";
?>