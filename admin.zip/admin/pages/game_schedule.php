<?php
include 'game_schedule_backend.php';
?>

<div class="card shadow p-4 mb-4">
    <h3 class="section-title mb-3">🗓️ Game Schedule (Day 1 → Day 5)</h3>

    <?php if (isset($_GET['created'])): ?><div class="alert alert-success">✅ Match created.</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success">✅ Match updated.</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success">✅ Match deleted.</div><?php endif; ?>
    <?php if (isset($_GET['winner_set'])): ?><div class="alert alert-success">✅ Winner set.</div><?php endif; ?>

    <!-- Create/Edit Form -->
    <div class="mb-4">
      <form method="POST" class="row g-3">
        <input type="hidden" name="match_id" value="<?= $editMatch ? intval($editMatch['id']) : 0; ?>">

        <div class="col-md-4">
          <label class="form-label">Sport</label>
          <select name="sport_id" class="form-select" required>
            <option value="">-- Select Sport --</option>
            <?php while ($s = $sports->fetch_assoc()): ?>
              <?php $sel = ($editMatch && $editMatch['sport_id'] == $s['id']) ? 'selected' : ''; ?>
              <option value="<?= $s['id'] ?>" <?= $sel ?>>
                <?= htmlspecialchars($s['sport_name']) ?> (<?= htmlspecialchars($s['category']) ?>)
              </option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="col-md-2">
          <label class="form-label">Day (1-5)</label>
          <select name="game_day" class="form-select" required>
            <?php for ($d=1;$d<=5;$d++): ?>
              <option value="<?= $d ?>" <?= ($editMatch && $editMatch['game_day']==$d) ? 'selected' : '' ?>>Day <?= $d ?></option>
            <?php endfor; ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Team A</label>
          <select name="team_a" class="form-select" required>
            <option value="">-- Select Team A --</option>
            <?php
              $departments->data_seek(0);
              while ($d = $departments->fetch_assoc()): ?>
              <option value="<?= $d['id'] ?>" <?= ($editMatch && $editMatch['team_a_id'] == $d['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($d['code']) ?>
              </option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Team B</label>
          <select name="team_b" class="form-select" required>
            <option value="">-- Select Team B --</option>
            <?php
              $departments->data_seek(0);
              while ($d = $departments->fetch_assoc()): ?>
              <option value="<?= $d['id'] ?>" <?= ($editMatch && $editMatch['team_b_id'] == $d['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($d['code']) ?>
              </option>
            <?php endwhile; ?>
          </select>
        </div>

        <div class="col-md-3">
          <label class="form-label">Date</label>
          <input type="date" name="game_date" class="form-control" value="<?= $editMatch ? htmlspecialchars($editMatch['game_date']) : '' ?>">
        </div>

        <div class="col-md-2">
          <label class="form-label">Time</label>
          <input type="time" name="game_time" class="form-control" value="<?= $editMatch ? htmlspecialchars($editMatch['game_time']) : '' ?>">
        </div>

        <div class="col-md-4">
          <label class="form-label">Location</label>
          <input type="text" name="location" class="form-control" value="<?= $editMatch ? htmlspecialchars($editMatch['location']) : '' ?>" placeholder="Optional">
        </div>

        <div class="col-12">
          <?php if ($editMatch): ?>
            <button type="submit" name="update_match" class="btn btn-primary">💾 Update Match</button>
            <a href="game_schedule.php" class="btn btn-secondary">Cancel</a>
          <?php else: ?>
            <button type="submit" name="create_match" class="btn btn-success">➕ Create Match</button>
          <?php endif; ?>
        </div>
      </form>
    </div>

    <!-- Schedule Table -->
    <div class="table-responsive">
      <table class="table table-bordered align-middle text-center">
        <thead class="table-dark">
          <tr>
            <th>Day</th>
            <th>Sport (Category)</th>
            <th>Team A</th>
            <th>Team B</th>
            <th>Date / Time</th>
            <th>Location</th>
            <th>Winner</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $schedule->fetch_assoc()): ?>
            <tr>
              <td>Day <?= intval($row['game_day']); ?></td>
              <td><?= htmlspecialchars($row['sport_name']) ?> (<?= htmlspecialchars($row['category']) ?>)</td>
              <td><?= htmlspecialchars($row['team_a_code']); ?></td>
              <td><?= htmlspecialchars($row['team_b_code']); ?></td>
              <td>
                <?= $row['game_date'] ? htmlspecialchars($row['game_date']) : '' ?>
                <?= $row['game_time'] ? ' / ' . htmlspecialchars($row['game_time']) : '' ?>
              </td>
              <td><?= $row['location'] ? htmlspecialchars($row['location']) : '<span class="small-muted">—</span>'; ?></td>
              <td><?= $row['winner_code'] ? '<strong>' . htmlspecialchars($row['winner_code']) . '</strong>' : '<span class="small-muted">—</span>'; ?></td>
              <td>
                <div class="d-flex flex-wrap justify-content-center align-items-center gap-2">
                  <a href="?edit=<?= intval($row['id']); ?>" class="btn btn-sm btn-outline-primary">✏️ Edit</a>

                  <form method="POST" class="d-flex align-items-center gap-2" style="margin:0;">
                    <input type="hidden" name="match_id" value="<?= intval($row['id']); ?>">
                    <select name="winner_id" class="form-select form-select-sm" style="width:140px;">
                      <option value="0">— Set Winner —</option>
                      <?php
                        $departments->data_seek(0);
                        while ($d = $departments->fetch_assoc()):
                      ?>
                        <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['code']) ?></option>
                      <?php endwhile; ?>
                    </select>
                    <button type="submit" name="set_winner" class="btn btn-sm btn-primary">🏁 Set</button>
                  </form>

                  <a href="?delete=<?= intval($row['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this match?');">🗑</a>
                </div>
              </td>
            </tr>
          <?php endwhile; ?>

          <?php if ($schedule->num_rows === 0): ?>
            <tr><td colspan="8">No matches scheduled yet.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

  </div>
