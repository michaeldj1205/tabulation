<?php
include 'event_results_backend.php';
?>

<div class="card shadow p-4 mb-5">
    <h3 class="section-title text-center mb-4">⚔️ Event Medal Results</h3>

    <?php if (isset($_GET['success'])): ?>
      <div class="alert alert-success text-center">✅ Results updated successfully!</div>
    <?php endif; ?>

    <div class="table-responsive">
      <table class="table table-bordered text-center align-middle">
        <thead>
          <tr>
            <th>Sport</th>
            <th>Category</th>
            <th>🥇 Gold</th>
            <th>🥈 Silver</th>
            <th>🥉 Bronze</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $deptList = [];
          $departments->data_seek(0);
          while ($d = $departments->fetch_assoc()) {
              $deptList[$d['id']] = $d['code'];
          }

          while ($r = $results->fetch_assoc()):
          ?>
          <tr>
            <form method="POST">
              <td><strong><?= htmlspecialchars($r['sport_name']); ?></strong></td>
              <td><?= htmlspecialchars($r['category']); ?></td>
              <input type="hidden" name="sport_id" value="<?= $r['sport_id']; ?>">
              <input type="hidden" name="result_id" value="<?= $r['result_id'] ?? 0; ?>">

              <td>
                <select name="gold_winner" class="form-select">
                  <option value="0">—</option>
                  <?php foreach ($deptList as $id => $code): ?>
                    <option value="<?= $id ?>" <?= ($r['gold_winner'] == $id) ? 'selected' : '' ?>><?= $code ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td>
                <select name="silver_winner" class="form-select">
                  <option value="0">—</option>
                  <?php foreach ($deptList as $id => $code): ?>
                    <option value="<?= $id ?>" <?= ($r['silver_winner'] == $id) ? 'selected' : '' ?>><?= $code ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td>
                <select name="bronze_winner" class="form-select">
                  <option value="0">—</option>
                  <?php foreach ($deptList as $id => $code): ?>
                    <option value="<?= $id ?>" <?= ($r['bronze_winner'] == $id) ? 'selected' : '' ?>><?= $code ?></option>
                  <?php endforeach; ?>
                </select>
              </td>

              <td>
                <?php if ($r['result_id']): ?>
                  <button type="submit" name="quick_update" class="btn btn-primary btn-sm">💾 Update</button>
                  <a href="../index.php?page=event_results&delete_result=<?= $r['result_id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this event result?');">🗑</a>
                <?php else: ?>
                  <button type="submit" name="save_result" class="btn btn-success btn-sm">➕ Add</button>
                <?php endif; ?>
              </td>
            </form>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
