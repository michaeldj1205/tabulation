<?php
include '../db_connect.php';

// ---------- Handle Create Match ----------
if (isset($_POST['create_match'])) {
    $sport_id = intval($_POST['sport_id']);
    $team_a = intval($_POST['team_a']);
    $team_b = intval($_POST['team_b']);
    $game_day = intval($_POST['game_day']);
    $game_date = !empty($_POST['game_date']) ? $_POST['game_date'] : null;
    $game_time = !empty($_POST['game_time']) ? $_POST['game_time'] : null;
    $location = !empty($_POST['location']) ? $_POST['location'] : null;

    $stmt = $conn->prepare("
        INSERT INTO game_schedule (sport_id, team_a_id, team_b_id, game_day, game_date, game_time, location)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("iiiisss", $sport_id, $team_a, $team_b, $game_day, $game_date, $game_time, $location);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php?page=game_schedule&created=1");
    exit();
}

// ---------- Handle Update Match ----------
if (isset($_POST['update_match'])) {
    $id = intval($_POST['match_id']);
    $sport_id = intval($_POST['sport_id']);
    $team_a = intval($_POST['team_a']);
    $team_b = intval($_POST['team_b']);
    $game_day = intval($_POST['game_day']);
    $game_date = !empty($_POST['game_date']) ? $_POST['game_date'] : null;
    $game_time = !empty($_POST['game_time']) ? $_POST['game_time'] : null;
    $location = !empty($_POST['location']) ? $_POST['location'] : null;

    $stmt = $conn->prepare("
        UPDATE game_schedule
        SET sport_id = ?, team_a_id = ?, team_b_id = ?, game_day = ?, game_date = ?, game_time = ?, location = ?
        WHERE id = ?
    ");
    $stmt->bind_param("iiiisssi", $sport_id, $team_a, $team_b, $game_day, $game_date, $game_time, $location, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php?page=game_schedule&updated=1");
    exit();
}

// ---------- Handle Set Winner ----------
if (isset($_POST['set_winner'])) {
    $match_id = intval($_POST['match_id']);
    $winner_id = intval($_POST['winner_id']);

    // Allow setting winner_id to NULL (0) to clear winner
    $stmt = $conn->prepare("UPDATE game_schedule SET winner_id = NULLIF(?, 0) WHERE id = ?");
    $stmt->bind_param("ii", $winner_id, $match_id);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php?page=game_schedule&winner_set=1");
    exit();
}

// ---------- Handle Delete ----------
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM game_schedule WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: index.php?page=game_schedule&deleted=1");
    exit();
}

// ---------- Edit Mode ----------
$editMatch = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $q = $conn->prepare("SELECT * FROM game_schedule WHERE id = ?");
    $q->bind_param("i", $id);
    $q->execute();
    $res = $q->get_result();
    $editMatch = $res->fetch_assoc();
    $q->close();

    // Clear edit mode after loading data
    unset($_GET['edit']);
}

// ---------- Fetch Data ----------
$sports = $conn->query("SELECT id, sport_name, category FROM sports ORDER BY sport_name ASC, category ASC");
$departments = $conn->query("SELECT id, code FROM departments ORDER BY code ASC");

$schedule_sql = "
    SELECT gs.*, s.sport_name, s.category,
           a.code AS team_a_code, b.code AS team_b_code, w.code AS winner_code
    FROM game_schedule gs
    JOIN sports s ON gs.sport_id = s.id
    JOIN departments a ON gs.team_a_id = a.id
    JOIN departments b ON gs.team_b_id = b.id
    LEFT JOIN departments w ON gs.winner_id = w.id
    ORDER BY gs.game_day ASC, gs.game_date ASC, gs.game_time ASC
";
$schedule = $conn->query($schedule_sql);
?>