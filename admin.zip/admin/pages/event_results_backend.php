<?php
include '../db_connect.php';

// 🏆 Save or Update Event Result
if (isset($_POST['save_result']) || isset($_POST['update_result']) || isset($_POST['quick_update'])) {
    $sport_id = intval($_POST['sport_id']);
    $gold = !empty($_POST['gold_winner']) ? intval($_POST['gold_winner']) : 0;
    $silver = !empty($_POST['silver_winner']) ? intval($_POST['silver_winner']) : 0;
    $bronze = !empty($_POST['bronze_winner']) ? intval($_POST['bronze_winner']) : 0;

    // 🔍 Get the sport's category (Men/Women/Mix)
    $cat_stmt = $conn->prepare("SELECT category FROM sports WHERE id = ?");
    $cat_stmt->bind_param("i", $sport_id);
    $cat_stmt->execute();
    $cat_result = $cat_stmt->get_result();
    $category = $cat_result->fetch_assoc()['category'] ?? 'Mix';
    $cat_stmt->close();

    // 🧩 UPDATE EXISTING RESULT
    if (isset($_POST['update_result']) || isset($_POST['quick_update'])) {
        $id = intval($_POST['result_id']);

        // Get previous winners (for recalculation)
        $prev = $conn->query("SELECT gold_winner, silver_winner, bronze_winner FROM event_results WHERE id=$id")->fetch_assoc();

        // Update event result safely (NULL for empty)
        $stmt = $conn->prepare("
            UPDATE event_results
            SET gold_winner = NULLIF(?, 0),
                silver_winner = NULLIF(?, 0),
                bronze_winner = NULLIF(?, 0)
            WHERE id = ?
        ");
        $stmt->bind_param("iiii", $gold, $silver, $bronze, $id);
        $stmt->execute();

        // Reset old medal counts by category
        if ($prev) {
            foreach (['gold_winner' => 'gold', 'silver_winner' => 'silver', 'bronze_winner' => 'bronze'] as $winner => $type) {
                if (!empty($prev[$winner])) {
                    $conn->query("
                        UPDATE medals
                        SET $type = GREATEST($type - 1, 0),
                            total = gold + silver + bronze
                        WHERE department_id = {$prev[$winner]}
                        AND category = '$category'
                    ");
                }
            }
        }
    } else {
        // 🧩 INSERT NEW EVENT RESULT
        $stmt = $conn->prepare("
            INSERT INTO event_results (sport_id, gold_winner, silver_winner, bronze_winner)
            VALUES (?, NULLIF(?, 0), NULLIF(?, 0), NULLIF(?, 0))
        ");
        $stmt->bind_param("iiii", $sport_id, $gold, $silver, $bronze);
        $stmt->execute();
    }

    // 🥇 FUNCTION TO UPDATE MEDALS PER CATEGORY
    function updateMedals($conn, $dept_id, $category, $gold, $silver, $bronze) {
        if (!$dept_id) return;

        // Check if this department/category combo exists
        $check = $conn->prepare("SELECT id FROM medals WHERE department_id=? AND category=?");
        $check->bind_param("is", $dept_id, $category);
        $check->execute();
        $res = $check->get_result();

        $total = $gold + $silver + $bronze;

        if ($res->num_rows > 0) {
            $stmt = $conn->prepare("
                UPDATE medals
                SET gold = gold + ?,
                    silver = silver + ?,
                    bronze = bronze + ?,
                    total = gold + silver + bronze
                WHERE department_id = ? AND category = ?
            ");
            $stmt->bind_param("iiiis", $gold, $silver, $bronze, $dept_id, $category);
        } else {
            $stmt = $conn->prepare("
                INSERT INTO medals (department_id, category, gold, silver, bronze, total)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("isiiii", $dept_id, $category, $gold, $silver, $bronze, $total);
        }
        $stmt->execute();
    }

    // 🥇 Update medals for each winner
    updateMedals($conn, $gold, $category, 1, 0, 0);
    updateMedals($conn, $silver, $category, 0, 1, 0);
    updateMedals($conn, $bronze, $category, 0, 0, 1);

    header("Location: index.php?page=event_results&success=1");
    exit();
}

// ❌ Delete Event Result
if (isset($_GET['delete_result'])) {
    $id = $_GET['delete_result'];

    $get_winners = $conn->prepare("
        SELECT e.gold_winner, e.silver_winner, e.bronze_winner, s.category
        FROM event_results e
        JOIN sports s ON e.sport_id = s.id
        WHERE e.id = ?
    ");
    $get_winners->bind_param("i", $id);
    $get_winners->execute();
    $result = $get_winners->get_result()->fetch_assoc();
    $get_winners->close();

    $stmt = $conn->prepare("DELETE FROM event_results WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    if ($result) {
        $category = $result['category'];
        foreach (['gold_winner' => 'gold', 'silver_winner' => 'silver', 'bronze_winner' => 'bronze'] as $winner => $type) {
            if (!empty($result[$winner])) {
                $conn->query("
                    UPDATE medals
                    SET $type = GREATEST($type - 1, 0),
                        total = gold + silver + bronze
                    WHERE department_id = {$result[$winner]}
                    AND category = '$category'
                ");
            }
        }
    }

    header("Location: index.php?page=event_results");
    exit();
}

// ✏️ Edit Result
$editData = null;
if (isset($_GET['edit_result'])) {
    $id = $_GET['edit_result'];
    $res = $conn->query("SELECT * FROM event_results WHERE id=$id");
    $editData = $res->fetch_assoc();
}

$sports = $conn->query("SELECT id, sport_name, category FROM sports ORDER BY sport_name ASC");
$departments = $conn->query("SELECT id, code FROM departments ORDER BY code ASC");

// Fetch all sports with results
$results = $conn->query("
    SELECT
        s.id AS sport_id,
        s.sport_name,
        s.category,
        e.id AS result_id,
        e.gold_winner,
        e.silver_winner,
        e.bronze_winner
    FROM sports s
    LEFT JOIN event_results e ON e.sport_id = s.id
    ORDER BY s.category, s.sport_name ASC
");
?>