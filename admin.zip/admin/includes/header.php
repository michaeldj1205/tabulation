<?php
session_start();
if (!isset($_SESSION["admin_logged_in"])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🏆 Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
.navbar { background-color: #212529; }
.navbar-brand, .nav-link { color: #fff !important; }
.card { border-radius: 15px; }
.table { border-radius: 10px; overflow: hidden; }
th { background-color: #212529 !important; color: white !important; }
.rank-1 { background-color: #fff3cd !important; }
.rank-2 { background-color: #e2e3e5 !important; }
.rank-3 { background-color: #f8d7da !important; }
.btn-sm { border-radius: 8px; transition: transform 0.1s ease-in-out; }
.btn-sm:hover { transform: scale(1.05); }
.section-title { font-weight: 700; color: #343a40; }
</style>
</head>
<body>

<!-- 🔝 NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">🏆 Admin Dashboard</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="index.php?page=dashboard">🥇 Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=event_results">⚔️ Event Results</a></li>
        <li class="nav-item"><a class="nav-link" href="index.php?page=game_schedule">🗓️ Game Schedule</a></li>
        <li class="nav-item"><a class="nav-link btn btn-danger text-white px-3 ms-2" href="../logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-5">